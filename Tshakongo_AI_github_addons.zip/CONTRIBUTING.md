
# Contribuer / Contributing

## FR
1. Forkez le repo et créez une branche feature.
2. Ajoutez des tests si possible.
3. Ouvrez une PR avec description claire.

## EN
1. Fork the repo and create a feature branch.
2. Add tests if possible.
3. Open a PR with a clear description.
