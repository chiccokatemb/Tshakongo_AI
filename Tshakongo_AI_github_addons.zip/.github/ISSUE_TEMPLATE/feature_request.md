
---
name: Feature request
about: Proposer une amélioration
title: "[FEATURE] "
labels: enhancement
---

**Résumé**
Décrivez l'idée.

**Valeur**
Pourquoi c'est utile ?

**Notes techniques**
...
