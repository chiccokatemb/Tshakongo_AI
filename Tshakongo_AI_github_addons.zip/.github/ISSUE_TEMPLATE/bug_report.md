
---
name: Bug report
about: Signaler un problème
title: "[BUG] "
labels: bug
---

**Description**
Décrivez le bug.

**Étapes pour reproduire**
1. ...
2. ...

**Comportement attendu**
...

**Logs / Captures**
...
