
# Tshakongo_AI

**FR** — Assistant vocal local pour Raspberry Pi avec neurone embarqué, vision, navigation LiDAR, MQTT domotique, scripts Docker, et dashboard web.

**EN** — Local voice assistant for Raspberry Pi with on-device neuron, vision, LiDAR navigation, home MQTT, Docker scripts, and web dashboard.

See `README.md` in the project root for full setup.
